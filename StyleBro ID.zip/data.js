const products = [
  {
    name: "Kaos Hitam Polos",
    category: "Kaos",
    price: 75000,
    image: "https://via.placeholder.com/200x250",
  },
  {
    name: "Kemeja Kotak-kotak",
    category: "Kemeja",
    price: 120000,
    image: "https://via.placeholder.com/200x250",
  },
  {
    name: "Celana Jeans Slim Fit",
    category: "Celana",
    price: 150000,
    image: "https://via.placeholder.com/200x250",
  },
];